const a= 5;
const b =6;
console.log(a+b);


if(a>b)
    console.log(a,"es mayor que ", b); 
else   
    console.log(a,"es menor que ", b);

    mensaje="Mi primer programa";
    console.log(mensaje);
    console.log(typeof(mensaje));
    
    const numero1 = 10;
    const numero2 = 5;
    const resultado = numero1 + numero2; 
    console.log(typeof(resultado));
    console.log(resultado);